# J.A.I.A.F.Y (جايفاي) — Android / Kotlin
1. افتح المجلد في Android Studio (Koala أو أحدث) وانتظر Gradle Sync.
2. Build > Build APK(s) — الملف في app/build/outputs/apk/debug/
3. على الجوال: ثبّت الـAPK، أدخل مفتاح OpenRouter (من openrouter.ai/keys) واسم النموذج إن أردت، فعّل خدمة "جايفاي" من إمكانية الوصول، ثم "تشغيل".
