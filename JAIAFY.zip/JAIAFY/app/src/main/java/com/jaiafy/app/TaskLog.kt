package com.jaiafy.app
import java.util.concurrent.CopyOnWriteArrayList

/** حالة المهمة الجارية (مثل بطاقة المهمة في الفيديو). */
object TaskLog {
    @Volatile var title = ""
    @Volatile var running = false
    @Volatile var steps = 0
    @Volatile var summary = ""
    @Volatile var startMs = 0L
    @Volatile var endMs = 0L
    val log = CopyOnWriteArrayList<String>()

    fun begin(t: String) { title = t; running = true; steps = 0; summary = ""; startMs = System.currentTimeMillis(); endMs = 0L; log.clear() }
    fun add(s: String) { steps++; log.add(s); while (log.size > 6) log.removeAt(0) }
    fun end(sum: String) { running = false; summary = sum; endMs = System.currentTimeMillis() }
    fun seconds(): Double {
        val e = if (running) System.currentTimeMillis() else endMs
        return ((e - startMs) / 100) / 10.0
    }
}
