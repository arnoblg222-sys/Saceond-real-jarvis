package com.jaiafy.app
import android.content.Context
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URL
import java.net.URLEncoder

/** تحكم بين أجهزة جايفاي على نفس الشبكة: كل جهاز عليه جايفاي يستقبل الأوامر برمز سري مشترك. */
object RemoteLink {
    private const val PORT = 8765
    @Volatile private var server: ServerSocket? = null

    fun start(c: Context, handler: (String) -> Unit) {
        if (server != null) return
        if (Brain.get(c, "remote_on") != "1" || Brain.get(c, "remote_token").isBlank()) return
        val token = Brain.get(c, "remote_token")
        Thread {
            try {
                val ss = ServerSocket(PORT); server = ss
                while (!ss.isClosed) {
                    val s = ss.accept()
                    Thread {
                        try {
                            val line = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8")).readLine() ?: ""
                            val path = line.split(" ").getOrNull(1) ?: ""
                            val u = Uri.parse("http://x$path")
                            val ok = u.path == "/cmd" && u.getQueryParameter("token") == token
                            val text = u.getQueryParameter("text") ?: ""
                            val reply = if (ok) "ok" else "denied"
                            s.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Length: " + reply.length + "\r\n\r\n" + reply).toByteArray())
                            s.close()
                            if (ok && text.isNotBlank()) handler(text)
                        } catch (_: Exception) { try { s.close() } catch (_: Exception) {} }
                    }.start()
                }
            } catch (_: Exception) { server = null }
        }.start()
    }

    fun stop() { try { server?.close() } catch (_: Exception) {}; server = null }

    /** يرسل أمراً لجهاز جايفاي آخر. الأجهزة في الإعدادات بصيغة: اسم=عنوان IP في كل سطر. */
    fun send(c: Context, name: String, text: String): String {
        val ip = Brain.get(c, "remote_devices").lines()
            .map { it.split("=") }.firstOrNull { it.size == 2 && it[0].trim().contains(name.trim(), true) }?.get(1)?.trim()
            ?: return "لا يوجد جهاز باسم $name في الإعدادات"
        return try {
            val url = "http://$ip:$PORT/cmd?token=" + URLEncoder.encode(Brain.get(c, "remote_token"), "UTF-8") +
                "&text=" + URLEncoder.encode(text, "UTF-8")
            val con = URL(url).openConnection() as HttpURLConnection
            con.connectTimeout = 5000; con.readTimeout = 5000
            val r = con.inputStream.bufferedReader().readText()
            if (r == "ok") "أُرسل الأمر إلى $name" else "رفض الجهاز الأمر (الرمز غير صحيح)"
        } catch (e: Exception) { "تعذر الوصول إلى $name" }
    }
}
