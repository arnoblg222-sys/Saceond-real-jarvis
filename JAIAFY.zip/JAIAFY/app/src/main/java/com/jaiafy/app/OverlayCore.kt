package com.jaiafy.app
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.random.Random

/** البطل الصغير يتمشى فوق التطبيقات الأخرى (يحتاج إذن "الظهور فوق التطبيقات"). الضغط عليه يفتح جايفاي. */
object OverlayCore {
    private var view: HeroView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var wm: WindowManager? = null
    private val h = Handler(Looper.getMainLooper())
    private var dir = 1
    private var pauseUntil = 0L
    private var nextPause = 0L
    private var screenW = 0
    private var stepPx = 6

    private val tick = object : Runnable {
        override fun run() {
            val v = view ?: return
            val p = lp ?: return
            val now = System.currentTimeMillis()
            if (now < pauseUntil) { v.walking = false } else {
                v.walking = true
                p.x += dir * stepPx
                if (p.x < 0) { p.x = 0; dir = 1 }
                if (p.x > screenW - p.width) { p.x = screenW - p.width; dir = -1 }
                v.facing = dir
                if (now > nextPause) { pauseUntil = now + 2000; nextPause = now + 8000 + Random.nextLong(6000); v.tapUntil = now + 700 }
            }
            try { wm?.updateViewLayout(v, p) } catch (_: Exception) {}
            h.postDelayed(this, 45)
        }
    }

    fun show(c: Context) {
        if (view != null || !Settings.canDrawOverlays(c)) return
        val ctx = c.applicationContext
        val d = ctx.resources.displayMetrics
        screenW = d.widthPixels
        stepPx = (2.2f * d.density).toInt().coerceAtLeast(3)
        val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val hero = HeroView(ctx)
        val params = WindowManager.LayoutParams((64 * d.density).toInt(), (100 * d.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.START; x = 0; y = (70 * d.density).toInt() }
        hero.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.actionMasked == MotionEvent.ACTION_UP)
                    ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                return true
            }
        })
        try { w.addView(hero, params) } catch (_: Exception) { return }
        wm = w; lp = params; view = hero
        nextPause = System.currentTimeMillis() + 6000
        h.post(tick)
    }

    /** حركة "ضغط" عند فتح تطبيق أو الضغط على الشاشة. */
    fun poke() { view?.let { it.tapUntil = System.currentTimeMillis() + 700; it.walking = false } }

    fun hide(c: Context) {
        h.removeCallbacks(tick)
        val v = view ?: return
        try { wm?.removeView(v) } catch (_: Exception) {}
        view = null; lp = null
    }
}
