package com.jaiafy.app
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.hardware.usb.UsbManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

/** ينفّذ الأوامر القادمة من العقل. يرجع نتيجة نصية (يستعملها العقل كخطوة تالية، أو تُنطق إن لم يكن هناك استكمال). */
class Actions(private val c: Context, private val mem: Memory) {
    private val sc get() = ScreenControlService.inst
    private val main = Handler(Looper.getMainLooper())

    fun run(a: JSONObject): String? {
        val arg = a.optString("arg")
        when (a.optString("type")) {
            "open_app" -> {
                val pm = c.packageManager
                val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .firstOrNull { it.loadLabel(pm).toString().contains(arg, true) }
                if (app == null) return "لم أجد التطبيق $arg"
                main.post { OverlayCore.poke() }
                c.startActivity(pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            "click_text" -> if (sc?.clickText(arg) != true) return "لم أجد $arg على الشاشة"
            "type_text" -> sc?.typeText(arg)
            "back" -> sc?.back()
            "home" -> sc?.home()
            "recents" -> sc?.recents()
            "scroll_down" -> sc?.swipe(true)
            "scroll_up" -> sc?.swipe(false)
            "swipe" -> sc?.swipeDir(arg)
            "tap" -> {
                val p = arg.split(",")
                val x = p.getOrNull(0)?.trim()?.toFloatOrNull(); val y = p.getOrNull(1)?.trim()?.toFloatOrNull()
                if (x != null && y != null) { main.post { OverlayCore.poke() }; sc?.tap(x, y) } else return "إحداثيات غير صالحة"
            }
            "read_screen" -> return sc?.readScreen() ?: "خدمة التحكم بالشاشة غير مفعّلة"
            "wait" -> { Thread.sleep(((arg.toDoubleOrNull() ?: 1.0).coerceIn(0.2, 10.0) * 1000).toLong()) }
            "search_web" -> openBrowser("https://www.google.com/search?q=" + Uri.encode(arg))
            "open_url" -> openBrowser(arg)
            "call" -> c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$arg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "flashlight_on", "flashlight_off" -> {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], a.optString("type") == "flashlight_on")
            }
            "volume_up", "volume_down" -> (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
                AudioManager.STREAM_MUSIC, if (a.optString("type") == "volume_up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "bt_list" -> return try {
                val bt = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                "الأجهزة المقترنة: " + bt.bondedDevices.joinToString("، ") { it.name }
            } catch (e: SecurityException) { "أحتاج إذن البلوتوث" }
            "usb_list" -> return "أجهزة USB: " + (c.getSystemService(Context.USB_SERVICE) as UsbManager).deviceList.values.joinToString("، ") { it.productName ?: it.deviceName }.ifBlank { "لا يوجد" }
            "remember" -> mem.add(arg)
            "save_skill" -> return try {
                val j = JSONObject(arg)
                mem.saveSkill(j.getString("name"), j.getJSONArray("steps"))
                "تم حفظ المهارة " + j.getString("name")
            } catch (e: Exception) { "تعذر حفظ المهارة" }
            "run_skill" -> {
                val steps: JSONArray = mem.skill(arg) ?: return "لا توجد مهارة باسم $arg"
                for (i in 0 until steps.length()) { run(steps.getJSONObject(i)); Thread.sleep(900) }
            }
            "remote" -> {
                val p = arg.split("|", limit = 2)
                return if (p.size == 2) RemoteLink.send(c, p[0], p[1]) else "الصيغة: اسم الجهاز|الأمر"
            }
            "show_cam" -> main.post { CameraFeed.show(c, Brain.get(c, "cam_url")) }
            "hide_cam" -> main.post { CameraFeed.hide(c) }
            "light_status" -> return SmartHome.describe(c)
            "light_on", "light_off" -> return if (SmartHome.set(c, a.optString("type") == "light_on")) null else "تعذر التحكم بالنور"
        }
        return null
    }

    /** يفتح Chromium إن كان مثبتاً، وإلا Chrome، وإلا المتصفح الافتراضي. */
    private fun openBrowser(url: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        for (pkg in listOf("org.chromium.chrome", "com.android.chrome")) {
            if (c.packageManager.getLaunchIntentForPackage(pkg) != null) { c.startActivity(i.setPackage(pkg)); return }
        }
        c.startActivity(i)
    }
}
