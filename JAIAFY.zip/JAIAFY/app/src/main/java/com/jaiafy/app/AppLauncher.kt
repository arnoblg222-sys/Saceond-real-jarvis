package com.jaiafy.app
import android.content.Context
import android.content.Intent

/** فتح التطبيقات محلياً وبصمت، مع أسماء عربية شائعة. */
object AppLauncher {
    private val alias = mapOf(
        "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "يوتيوب" to "youtube", "كروم" to "chrome",
        "انستغرام" to "instagram", "انستقرام" to "instagram", "تيك توك" to "tiktok", "سناب" to "snapchat",
        "سناب شات" to "snapchat", "تلغرام" to "telegram", "تليجرام" to "telegram", "الكاميرا" to "camera",
        "كاميرا" to "camera", "الاعدادات" to "settings", "الإعدادات" to "settings", "اعدادات" to "settings",
        "الهاتف" to "phone", "الرسائل" to "messages", "الخرائط" to "maps", "جيميل" to "gmail",
        "تويتر" to "twitter", "اكس" to "x", "فيسبوك" to "facebook", "ماسنجر" to "messenger",
        "سبوتيفاي" to "spotify", "نتفلكس" to "netflix", "ديسكورد" to "discord", "جوجل" to "google",
        "قوقل" to "google", "الساعة" to "clock", "الحاسبة" to "calculator", "الصور" to "photos",
        "المعرض" to "gallery", "بلاي ستور" to "play store", "متجر بلاي" to "play store"
    )

    /** يرجع true إذا فتح تطبيقاً. exact=true يشترط تطابق الاسم تماماً (لما يقول المستخدم اسم التطبيق فقط). */
    fun open(c: Context, spoken: String, exact: Boolean): Boolean {
        val q0 = spoken.trim().lowercase()
        if (q0.length < 2) return false
        val q = alias[q0] ?: q0
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: if (!exact) apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } else null
        val intent = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) } ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(intent); true } catch (e: Exception) { false }
    }
}
