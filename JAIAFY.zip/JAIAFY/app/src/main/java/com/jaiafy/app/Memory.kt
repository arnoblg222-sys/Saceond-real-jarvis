package com.jaiafy.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** ذاكرة جايفاي المستقلة: حقائق تعلّمها عنك، ومهارات محفوظة، وآخر المحادثات. كلها على الجهاز فقط. */
class Memory(ctx: Context) {
    private val file = File(ctx.filesDir, "memory.json")
    private val skillFile = File(ctx.filesDir, "skills.json")
    private val facts = JSONArray(if (file.exists()) file.readText() else "[]")
    private val skills = JSONObject(if (skillFile.exists()) skillFile.readText() else "{}")
    private val history = ArrayList<String>()

    @Synchronized fun add(fact: String) {
        if (fact.isBlank()) return
        for (i in 0 until facts.length()) if (facts.getString(i).equals(fact, true)) return
        facts.put(fact)
        if (facts.length() > 300) {
            val keep = JSONArray()
            for (i in facts.length() - 300 until facts.length()) keep.put(facts.get(i))
            file.writeText(keep.toString())
        } else file.writeText(facts.toString())
    }

    @Synchronized fun skill(name: String): JSONArray? {
        val k = skills.keys().asSequence().firstOrNull { it.equals(name, true) } ?: return null
        return skills.optJSONArray(k)
    }

    @Synchronized fun saveSkill(name: String, steps: JSONArray) {
        skills.put(name, steps)
        skillFile.writeText(skills.toString())
    }

    @Synchronized fun addTurn(user: String, bot: String) {
        history.add("المستخدم: $user\nجايفاي: $bot")
        while (history.size > 8) history.removeAt(0)
    }

    @Synchronized fun context(): String {
        val sb = StringBuilder("ما تعرفه عن المستخدم:\n")
        for (i in 0 until facts.length()) sb.append("- ").append(facts.getString(i)).append('\n')
        sb.append("المهارات المحفوظة: ").append(skills.keys().asSequence().joinToString("، ")).append('\n')
        if (history.isNotEmpty()) sb.append("آخر المحادثات:\n").append(history.joinToString("\n"))
        return sb.toString()
    }

    @Synchronized fun clear() {
        file.delete(); skillFile.delete(); history.clear()
        while (facts.length() > 0) facts.remove(0)
        for (k in skills.keys().asSequence().toList()) skills.remove(k)
    }
}
