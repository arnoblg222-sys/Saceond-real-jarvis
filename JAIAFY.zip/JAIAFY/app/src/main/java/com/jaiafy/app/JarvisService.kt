package com.jaiafy.app
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.ImageFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** خدمة تعمل بالخلفية: تصفيق → فتح التطبيق → استماع → وكيل ذكي (خطوات) → نطق. */
class JarvisService : LifecycleService() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var speaker: Speaker
    private lateinit var mem: Memory
    private lateinit var actions: Actions
    private lateinit var clap: ClapDetector
    private var recognizer: SpeechRecognizer? = null
    private val capture = ImageCapture.Builder().build()
    @Volatile private var guardOn = false
    private var lastAlert = 0L

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jaiafy", "جايفاي", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "تنبيهات جايفاي", NotificationManager.IMPORTANCE_HIGH))
        startForeground(1, Notification.Builder(this, "jaiafy").setContentTitle("جايفاي يستمع للتصفيق")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        speaker = Speaker(this); mem = Memory(this); actions = Actions(this, mem)
        Bus.say = { t -> speaker.say(t) }
        refreshFlags()
        clap = ClapDetector({ main.post { onWake() } }, { rms -> if (guardOn) onLoud(rms) })
        clap.start()
        ProcessCameraProvider.getInstance(this).also { f -> f.addListener({
            try { f.get().bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, capture) } catch (_: Exception) {}
        }, ContextCompat.getMainExecutor(this)) }
        RemoteLink.start(this) { cmd -> Thread { agent(cmd, null, false) }.start() }
        idleCheck()
    }

    private fun refreshFlags() {
        guardOn = Brain.get(this, "guard_on") == "1"
        main.postDelayed({ refreshFlags() }, 5000)
    }

    /** إذا طال الصمت وكان وجهك ظاهراً أمام الكاميرا يسأل أين أنت. */
    private fun idleCheck() {
        main.postDelayed({
            val minutes = Brain.get(this, "idle_min").toLongOrNull() ?: 30L
            if (minutes > 0 && System.currentTimeMillis() - Bus.lastUserAt > minutes * 60000 && Bus.faceVisible()) {
                Bus.lastUserAt = System.currentTimeMillis()
                speaker.say("أين أنت؟ متى سنتحدث؟")
            }
            idleCheck()
        }, 60000)
    }

    private fun onWake() {
        Bus.lastUserAt = System.currentTimeMillis()
        OverlayCore.show(this)
        try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
        if (Mode.serious) main.post { listen() } else speaker.say("أهلاً بك سيدي") { main.post { listen() } }
    }

    private fun muteBeep() {
        try {
            val am = getSystemService(AudioManager::class.java)
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            main.postDelayed({ try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {} }, 700)
        } catch (_: Exception) {}
    }

    private fun listen() {
        recognizer?.destroy()
        var partial = ""
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: android.os.Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) rearm() else think(t)
                }
                override fun onError(e: Int) {
                    if (partial.isNotBlank()) speaker.say("هل أكل القط لسانك؟") { rearm() } else rearm()
                }
                override fun onPartialResults(p: android.os.Bundle?) {
                    partial = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: partial
                }
                override fun onReadyForSpeech(p: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: android.os.Bundle?) {}
            })
            muteBeep()
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA"))
        }
    }

    private val seriousWords = listOf("serious", "سيريوس", "سيريس", "سيرياس", "سيريوز", "سيريز", "سريوس")
    private val openVerbs = listOf("افتح", "شغل", "شغّل", "open")

    /** أوامر محلية فورية: وضع Serious، Holo Desk، وفتح التطبيقات بصمت. */
    private fun local(text: String): Boolean {
        val n = text.trim().lowercase()
        if (seriousWords.any { n.contains(it) }) {
            Mode.serious = !(n.contains("normal") || n.contains("عادي") || n.contains("طبيعي"))
            if (Mode.serious) speaker.say("مستعد") { rearm() } else rearm()
            return true
        }
        if (n.contains("normal mode") || n == "عادي" || n.contains("وضع عادي")) { Mode.serious = false; rearm(); return true }
        if (n.contains("holo") || n.contains("هولو")) {
            try {
                startActivity(Intent(this, MainActivity::class.java).putExtra("page", 2)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            } catch (_: Exception) {}
            rearm(); return true
        }
        val verb = openVerbs.firstOrNull { n.startsWith("$it ") }
        val name = if (verb != null) n.removePrefix("$verb ").trim() else n
        val ok = AppLauncher.open(this, name, exact = verb == null)
        if (ok) { main.post { OverlayCore.poke() }; rearm() }
        return ok
    }

    private fun think(text: String, jpeg: ByteArray? = null) {
        Bus.lastUserAt = System.currentTimeMillis()
        if (jpeg == null && local(text)) return
        Thread { agent(text, jpeg, true) }.start()
    }

    /** لقطة من كاميرا الجوال أو كاميرا المراقبة، تُنتظر حتى تصل (لا تُستدعى من الخيط الرئيسي). */
    private fun grab(cam: Boolean): ByteArray? {
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        main.post {
            if (cam) { out = CameraFeed.snapshot(); latch.countDown() }
            else capture.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(img: ImageProxy) {
                    val b = ByteArray(img.planes[0].buffer.remaining()); img.planes[0].buffer.get(b)
                    val fmt = img.format; img.close()
                    if (fmt == ImageFormat.JPEG) out = b
                    latch.countDown()
                }
                override fun onError(e: ImageCaptureException) { latch.countDown() }
            })
        }
        latch.await(6, TimeUnit.SECONDS)
        return out
    }

    /** الوكيل: يكرر (فكّر ← نفّذ ← اقرأ النتيجة) حتى تنتهي المهمة أو يبلغ 8 خطوات. */
    private fun agent(text: String, jpeg0: ByteArray?, speak: Boolean) {
        var prompt = text
        var jpeg = jpeg0
        var finalSay = ""
        var titled = false
        val t0 = System.currentTimeMillis()
        var lastFiller = t0
        var rounds = 0
        while (rounds < 8) {
            rounds++
            val r = Brain.ask(this, prompt, mem.context(), jpeg)
            jpeg = null
            val task = r.optString("task")
            if (task.isNotBlank() && !titled) { TaskLog.begin(task); titled = true }
            val say = r.optString("say")
            val acts = r.optJSONArray("actions")
            val cont = r.optBoolean("continue", false)
            val obs = ArrayList<String>()
            var wantsLook = false
            var wantsCam = false
            if (acts != null) for (i in 0 until acts.length()) {
                val a = acts.getJSONObject(i)
                val type = a.optString("type")
                if (titled) TaskLog.add(type + " " + a.optString("arg").take(14))
                when (type) {
                    "look" -> wantsLook = true
                    "look_cam" -> wantsCam = true
                    else -> actions.run(a)?.let { obs.add(it) }
                }
            }
            if (wantsLook || wantsCam) {
                jpeg = grab(wantsCam)
                prompt = "الطلب الأصلي: $text\nالصورة المرفقة هي ما طلبته، أجب الآن." + if (jpeg == null) " (تعذر الالتقاط)" else ""
                finalSay = say
                continue
            }
            if (!cont) {
                finalSay = if (say.isNotBlank()) say else obs.joinToString("。")
                break
            }
            prompt = "الطلب الأصلي: $text\nنتائج الأدوات: " + obs.joinToString(" | ").ifBlank { "تم" }.take(3500)
            if (speak && !Mode.serious && System.currentTimeMillis() - lastFiller > 20000 && System.currentTimeMillis() - t0 > 12000) {
                lastFiller = System.currentTimeMillis()
                Bus.say?.invoke("ما زلت أعمل على ذلك، سيدي")
            }
        }
        if (titled) TaskLog.end(finalSay.ifBlank { "تم" })
        mem.addTurn(text, finalSay)
        if (!speak) return
        if (finalSay.isBlank()) main.post { rearm() } else main.post { speaker.say(finalSay) { rearm() } }
    }

    /** صوت مرتفع مستمر: إشعار عالي الأولوية، ورسالة Telegram إن كانت مفعّلة. */
    private fun onLoud(rms: Int) {
        val now = System.currentTimeMillis()
        if (now - lastAlert < 60000) return
        lastAlert = now
        val msg = "تنبيه: صوت مرتفع عند " + java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()) + " (شدة $rms)"
        getSystemService(NotificationManager::class.java).notify(2,
            Notification.Builder(this, "alert").setContentTitle("جايفاي — تنبيه").setContentText(msg)
                .setSmallIcon(android.R.drawable.ic_dialog_alert).build())
        val tok = Brain.get(this, "tg_token"); val cid = Brain.get(this, "tg_chat")
        if (tok.isNotBlank() && cid.isNotBlank()) Thread {
            try { java.net.URL("https://api.telegram.org/bot$tok/sendMessage?chat_id=$cid&text=" + java.net.URLEncoder.encode(msg, "UTF-8")).readText() } catch (_: Exception) {}
        }.start()
    }

    private fun rearm() { recognizer?.destroy(); clap.start() }

    override fun onDestroy() {
        clap.stop(); recognizer?.destroy(); speaker.shutdown(); RemoteLink.stop(); Bus.say = null
        try { getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {}
        super.onDestroy()
    }
}
