package com.jaiafy.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** ثلاث صفحات: الكرة الزرقاء، الوجه، Holo Desk. بطاقة المهمة أسفل اليسار، وأيقونة الإعدادات أعلى اليمين. */
class MainActivity : FragmentActivity() {
    private val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
        Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CALL_PHONE)
    private var pager: Pager? = null
    private var pendingPage = -1

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        pendingPage = intent.getIntExtra("page", -1)
        buildUi()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val p = intent.getIntExtra("page", -1)
        if (p >= 0) { val pg = pager; if (pg != null) pg.go(p) else pendingPage = p }
    }

    override fun onStart() { super.onStart(); OverlayCore.hide(this) }
    override fun onStop() { OverlayCore.show(this); super.onStop() }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val hud = JarvisHud(this)
        val face = FaceView(this)
        val desk = HoloDeskView(this)
        val dots = List(3) {
            TextView(this).apply { text = "●"; textSize = 14f; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        }
        fun paintDots(i: Int) {
            dots.forEachIndexed { k, v -> v.setTextColor(if (k == i) 0xFFFFFFFF.toInt() else 0x66FFFFFF) }
        }
        val pg = Pager(this, listOf(hud, face, desk)) { i ->
            paintDots(i)
            if (i == 2) desk.start() else desk.stop()
        }
        pager = pg
        dots.forEachIndexed { k, v -> v.setOnClickListener { pg.go(k) } }
        paintDots(0)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            dots.forEach { addView(it) }
        }
        val gear = TextView(this).apply {
            text = "⚙"; textSize = 26f; setTextColor(0xCC5FE3FF.toInt())
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val root = FrameLayout(this)
        root.addView(pg, FrameLayout.LayoutParams(-1, -1))
        root.addView(TaskCardView(this), FrameLayout.LayoutParams(dp(250), dp(68)).apply {
            gravity = Gravity.BOTTOM or Gravity.START; leftMargin = dp(10); bottomMargin = dp(110) })
        root.addView(bar, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; topMargin = dp(28) })
        root.addView(gear, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.TOP or Gravity.END; topMargin = dp(20); rightMargin = dp(4) })
        setContentView(root)

        if (pendingPage >= 0) { pg.go(pendingPage); pendingPage = -1 }
        if (Brain.get(this, "key").isBlank()) startActivity(Intent(this, SettingsActivity::class.java))
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startService() else requestPermissions(missing.toTypedArray(), 1)
    }

    private fun startService() = ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startService()
    }
}
