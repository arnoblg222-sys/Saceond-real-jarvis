package com.jaiafy.app
/** الوضع الحالي: عادي (أزرق) أو جدّي Serious (أحمر). */
object Mode { @Volatile var serious = false }
