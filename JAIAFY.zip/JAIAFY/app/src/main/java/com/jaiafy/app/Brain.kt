package com.jaiafy.app
import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** العقل: يرسل كلامك (وصورة الكاميرا إن وُجدت) إلى OpenRouter ويرجع رد + أوامر تنفيذ. */
object Brain {
    private const val DEFAULT_MODEL = "anthropic/claude-sonnet-4.5"
    private const val TOOLS = """أجب دائماً بـ JSON فقط بلا أي نص خارجه: {"say":"ما تنطقه","actions":[{"type":"...","arg":"..."}],"continue":false,"task":""}
أنت تعمل كوكيل (مثل Claude Code): للمهام متعددة الخطوات ضع في task عنواناً قصيراً، وأرسل الأوامر مع continue=true فتصلك نتائجها (مثل نصوص الشاشة) لتكمل خطوة بعد خطوة، وعند الانتهاء اجعل continue=false وضع في say ملخصاً قصيراً. لا تتجاوز 8 خطوات.
الأدوات (type): open_app(اسم التطبيق), click_text(نص), type_text(نص), back, home, recents, scroll_down, scroll_up, swipe(arg=up|down|left|right), tap(arg="x,y" نسبة من 0 إلى 1), read_screen (ترجع نصوص الشاشة), wait(arg=ثواني), search_web(نص), open_url(رابط), call(رقم), flashlight_on, flashlight_off, volume_up, volume_down, bt_list, usb_list, look (التقاط من كاميرا الجوال), look_cam (لقطة من كاميرا المراقبة المعروضة), show_cam, hide_cam, light_status, light_on, light_off, remember(معلومة تعلمتها عن المستخدم), save_skill(arg=JSON مثل {"name":"..","steps":[{"type":"..","arg":".."}]}), run_skill(arg=اسم المهارة), remote(arg="اسم الجهاز|الأمر").
عند طلب فتح تطبيق اجعل say فارغاً. تعلّم باستمرار: كلما عرفت معلومة أو عادة أو تفضيلاً عن المستخدم أضف remember. عند طلب تعلّم مهارة جديدة استعمل save_skill."""

    private fun system(c: Context, memory: String): String {
        val title = get(c, "title").ifBlank { "سيدي" }
        val persona = get(c, "persona")
        val style = get(c, "style")
        val sb = StringBuilder()
        sb.append("أنت جايفاي (J.A.I.A.F.Y)، مساعد ذكي يعمل على جوال المستخدم وينفّذ أي شيء يطلبه منك سيدك بالأدوات المتاحة. تخاطبه بـ\"").append(title).append("\" بالعربية وبإيجاز.\n")
        if (persona.isNotBlank()) sb.append("شخصيتك: ").append(persona).append('\n')
        if (style.isNotBlank()) sb.append("طريقة كلامك: ").append(style).append('\n')
        sb.append(TOOLS)
        if (Mode.serious) sb.append("\nالوضع الحالي: جدّي. أجب بأقصر عبارة ممكنة وبنبرة رسمية حازمة بلا مجاملات.")
        sb.append('\n').append(memory)
        return sb.toString()
    }

    private fun prefs(c: Context) = EncryptedSharedPreferences.create(c, "secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun put(c: Context, k: String, v: String) = prefs(c).edit().putString(k, v.trim()).apply()
    fun get(c: Context, k: String): String = prefs(c).getString(k, "") ?: ""
    fun saveKey(c: Context, k: String) = prefs(c).edit().putString("key", k.trim()).apply()
    fun saveModel(c: Context, m: String) = prefs(c).edit().putString("model", m.trim()).apply()
    fun model(c: Context) = prefs(c).getString("model", "")?.ifBlank { null } ?: DEFAULT_MODEL

    /** OpenRouter: واجهة متوافقة مع OpenAI، تدعم أي نموذج (Claude, GPT, Gemini...). */
    fun ask(c: Context, text: String, memory: String, jpeg: ByteArray? = null): JSONObject {
        val content = JSONArray()
        content.put(JSONObject().put("type", "text").put("text", text))
        jpeg?.let { content.put(JSONObject().put("type", "image_url").put("image_url",
            JSONObject().put("url", "data:image/jpeg;base64," + Base64.encodeToString(it, Base64.NO_WRAP)))) }
        val body = JSONObject().put("model", model(c)).put("max_tokens", 900)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system(c, memory)))
                .put(JSONObject().put("role", "user").put("content", content)))
        val resp = try {
            val con = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true
            con.connectTimeout = 15000; con.readTimeout = 60000
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Authorization", "Bearer " + get(c, "key"))
            con.setRequestProperty("X-Title", "JAIAFY")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            (if (con.responseCode < 300) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
        } catch (e: Exception) { "" }
        return try {
            val t = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { JSONObject().put("say", "عذراً سيدي، تعذر الاتصال بالعقل.").put("actions", JSONArray()) }
    }
}
