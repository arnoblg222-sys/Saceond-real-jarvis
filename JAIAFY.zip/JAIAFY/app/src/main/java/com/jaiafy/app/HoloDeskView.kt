package com.jaiafy.app
import android.Manifest
import android.app.DownloadManager
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.media.FaceDetector
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.hypot

/**
 * Holo Desk: الكاميرا خلفية، وفوقها خلفية هولوغرافية ونوافذ زجاجية (تطبيقات، صور، ملفات، متصفح، ذاكرة).
 * تتبع اليدين مخفي: القرص (إبهام+سبابة) = لمس وسحب، ويدان مقروصتان = تكبير النافذة المختارة.
 * وتعليقات ذكية تعتمد على ما تراه الكاميرا.
 */
class HoloDeskView(private val act: FragmentActivity) : FrameLayout(act) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val cy = 0xFF5FE3FF.toInt()
    private val ui = Handler(Looper.getMainLooper())
    private val preview = PreviewView(act).apply {
        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        scaleType = PreviewView.ScaleType.FILL_CENTER
    }
    private val status = TextView(act).apply { setTextColor(0xFF8FA6B8.toInt()); textSize = 12f }
    private val cursor = View(act).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x4422E08A); setStroke(dp(2), 0xFF22E08A.toInt()) }
        visibility = View.GONE
    }
    private var started = false
    private var provider: ProcessCameraProvider? = null
    private var useCase: Preview? = null
    private var tracker: HandTracker? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val panels = HashMap<String, GlassPanel>()
    private var selected: GlassPanel? = null
    private val onSelect: (GlassPanel) -> Unit = { p -> selected?.select(false); p.select(true); selected = p }
    private var cascade = 0
    private var frameN = 0
    private var lastReact = 0L
    private var pinching = false
    private var downTime = 0L
    private var curX = 0f
    private var curY = 0f
    private var twoStart = 0f
    private var twoBase = 1f

    init {
        setBackgroundColor(0xFF02070D.toInt())
        addView(preview, FrameLayout.LayoutParams(-1, -1))
        addView(View(act).apply { setBackgroundColor(0x66020B14) }, FrameLayout.LayoutParams(-1, -1))
        addView(HoloBackdrop(act), FrameLayout.LayoutParams(-1, -1))
        addView(status, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.TOP or Gravity.START; leftMargin = dp(16); topMargin = dp(60) })
        val dock = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for ((label, key) in listOf("التطبيقات" to "apps", "الصور" to "photos", "الملفات" to "files", "المتصفح" to "browser", "الذاكرة" to "memory")) {
            val b = TextView(act).apply {
                text = label; gravity = Gravity.CENTER; setTextColor(cy); textSize = 10f
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x55104060); setStroke(dp(1), cy) }
                setOnClickListener { toggle(key) }
            }
            dock.addView(b, LinearLayout.LayoutParams(dp(58), dp(58)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        addView(dock, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dp(28) })
        addView(cursor, FrameLayout.LayoutParams(dp(30), dp(30)))
    }

    fun start() {
        if (started) return
        if (ContextCompat.checkSelfPermission(act, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        started = true
        val t = HandTracker(act, { hands -> post { handleHands(hands) } }, { msg -> post { status.text = msg } })
        t.onFrame = { bmp -> frameN++; if (frameN % 12 == 0) detectFace(bmp) }
        tracker = t
        val f = ProcessCameraProvider.getInstance(act)
        f.addListener({
            try {
                val p = f.get()
                val pr = Preview.Builder().build()
                pr.setSurfaceProvider(preview.surfaceProvider)
                p.bindToLifecycle(act, CameraSelector.DEFAULT_FRONT_CAMERA, pr, t.analysis)
                provider = p; useCase = pr
                t.start(exec)
                ui.postDelayed(react, 9000)
            } catch (_: Exception) { started = false; status.text = "تعذر فتح الكاميرا الأمامية" }
        }, ContextCompat.getMainExecutor(act))
    }

    fun stop() {
        ui.removeCallbacks(react)
        releaseTouch()
        cursor.visibility = View.GONE
        tracker?.let { t -> provider?.unbind(t.analysis); t.close() }
        useCase?.let { provider?.unbind(it) }
        tracker = null; useCase = null; started = false
    }

    // ---------- تتبع اليدين ----------
    private fun inject(action: Int) {
        val e = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, curX, curY, 0)
        dispatchTouchEvent(e); e.recycle()
    }

    private fun releaseTouch() { if (pinching) { pinching = false; inject(MotionEvent.ACTION_UP) } }

    private fun handleHands(hands: List<Hand>) {
        if (width == 0 || !started) return
        if (hands.isEmpty()) { cursor.visibility = View.GONE; releaseTouch(); twoStart = 0f; return }
        if (cursor.visibility != View.VISIBLE) { cursor.visibility = View.VISIBLE; cursor.bringToFront() }
        if (hands.size >= 2 && hands[0].pinch && hands[1].pinch) {
            releaseTouch()
            val p = selected ?: return
            val dist = hypot((hands[0].x - hands[1].x) * width, (hands[0].y - hands[1].y) * height)
            if (twoStart == 0f) { twoStart = dist; twoBase = p.scaleX }
            else { val s = (twoBase * dist / twoStart).coerceIn(0.5f, 2.5f); p.scaleX = s; p.scaleY = s }
            return
        }
        twoStart = 0f
        val h = hands[0]
        curX += (h.x * width - curX) * 0.5f
        curY += (h.y * height - curY) * 0.5f
        cursor.x = curX - dp(15); cursor.y = curY - dp(15)
        (cursor.background as GradientDrawable).setStroke(dp(2), if (h.pinch) 0xFF22E08A.toInt() else cy)
        if (h.pinch && !pinching) { pinching = true; downTime = SystemClock.uptimeMillis(); inject(MotionEvent.ACTION_DOWN) }
        else if (h.pinch) inject(MotionEvent.ACTION_MOVE)
        else releaseTouch()
    }

    // ---------- الوجه والتعليقات الذكية ----------
    private fun detectFace(b: Bitmap) {
        try {
            val w = 240
            var hh = (b.height * 240f / b.width).toInt()
            if (hh % 2 == 1) hh++
            val small = Bitmap.createScaledBitmap(b, w, hh, true).copy(Bitmap.Config.RGB_565, false)
            val faces = arrayOfNulls<FaceDetector.Face>(1)
            if (FaceDetector(w, hh, 1).findFaces(small, faces) > 0) Bus.faceSeenAt = System.currentTimeMillis()
        } catch (_: Exception) {}
    }

    private val react = object : Runnable {
        override fun run() { if (started) doReact(); ui.postDelayed(this, 9000) }
    }

    private fun doReact() {
        if (Brain.get(act, "react_off") == "1" || Brain.get(act, "key").isBlank()) return
        if (System.currentTimeMillis() - lastReact < 25000) return
        val bmp = preview.bitmap ?: return
        val scaled = Bitmap.createScaledBitmap(bmp, 480, (bmp.height * 480f / bmp.width).toInt().coerceAtLeast(1), true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
        val jpg = out.toByteArray()
        Thread {
            val r = Brain.ask(act, REACT_PROMPT, "", jpg)
            val say = r.optString("say")
            if (say.isNotBlank() && !say.contains("تعذر")) { lastReact = System.currentTimeMillis(); Bus.say?.invoke(say) }
        }.start()
    }

    // ---------- النوافذ ----------
    private fun toggle(key: String) {
        val old = panels[key]
        if (old != null) {
            panels.remove(key)
            old.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(180).withEndAction { removeView(old) }.start()
            return
        }
        val (title, width) = when (key) {
            "apps" -> "التطبيقات" to 220
            "photos" -> "الصور" to 270
            "files" -> "الملفات" to 240
            "memory" -> "الذاكرة" to 250
            else -> "المتصفح" to 310
        }
        val p = GlassPanel(act, title, onSelect)
        when (key) {
            "apps" -> appsContent(p)
            "photos" -> photosContent(p)
            "files" -> filesContent(p)
            "memory" -> memoryContent(p)
            else -> browserContent(p)
        }
        addView(p, FrameLayout.LayoutParams(dp(width), -2).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(16 + cascade * 14); topMargin = dp(90 + cascade * 14)
        })
        cursor.bringToFront()
        cascade = (cascade + 1) % 5
        p.alpha = 0f; p.scaleX = 0.8f; p.scaleY = 0.8f
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).setInterpolator(OvershootInterpolator()).start()
        onSelect(p); panels[key] = p
    }

    private fun memoryContent(p: GlassPanel) {
        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val facts = try { JSONArray(File(act.filesDir, "memory.json").readText()) } catch (e: Exception) { JSONArray() }
        val skills = try { JSONObject(File(act.filesDir, "skills.json").readText()) } catch (e: Exception) { JSONObject() }
        fun row(t: String) = list.addView(TextView(act).apply {
            text = t; setTextColor(0xFFCFEFFF.toInt()); textSize = 12f; setPadding(dp(4), dp(4), dp(4), dp(4)) })
        if (facts.length() == 0 && skills.length() == 0) row("لم أتعلم شيئاً بعد")
        for (k in skills.keys().asSequence()) row("⚙ مهارة: $k")
        for (i in maxOf(0, facts.length() - 40) until facts.length()) row("• " + facts.getString(i))
        p.addView(ScrollView(act).apply { addView(list) }, LinearLayout.LayoutParams(-1, dp(240)))
    }

    private fun appsContent(p: GlassPanel) {
        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val pm = act.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .sortedBy { it.loadLabel(pm).toString() }.take(80).forEach { ri ->
                list.addView(TextView(act).apply {
                    text = "▸ " + ri.loadLabel(pm)
                    setTextColor(0xFFCFEFFF.toInt()); textSize = 13f
                    setPadding(dp(4), dp(7), dp(4), dp(7))
                    setOnClickListener { pm.getLaunchIntentForPackage(ri.activityInfo.packageName)?.let { act.startActivity(it) } }
                })
            }
        p.addView(ScrollView(act).apply { addView(list) }, LinearLayout.LayoutParams(-1, dp(240)))
    }

    private fun thumb(uri: Uri): Bitmap? = try {
        act.contentResolver.openInputStream(uri)?.use { s ->
            BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = 8 })
        }
    } catch (e: Exception) { null }

    private fun photosContent(p: GlassPanel) {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(act, perm) != PackageManager.PERMISSION_GRANTED) {
            p.addRow("اضغط هنا للسماح بالوصول للصور، ثم أعد فتح النافذة")
                .setOnClickListener { act.requestPermissions(arrayOf(perm), 3) }
            return
        }
        val uriBase = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val ids = ArrayList<Long>()
        act.contentResolver.query(uriBase, arrayOf(MediaStore.Images.Media._ID), null, null,
            MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { c ->
            var k = 0
            while (c.moveToNext() && k < 12) { ids.add(c.getLong(0)); k++ }
        }
        val grid = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        ids.forEachIndexed { i, id ->
            if (i % 3 == 0) { val r = LinearLayout(act); row = r; grid.addView(r) }
            val uri = ContentUris.withAppendedId(uriBase, id)
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(thumb(uri))
                setOnClickListener {
                    act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
            }
            row!!.addView(iv, LinearLayout.LayoutParams(dp(80), dp(80)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        if (ids.isEmpty()) p.addRow("لا توجد صور")
        p.addView(ScrollView(act).apply { addView(grid) }, LinearLayout.LayoutParams(-1, dp(250)))
    }

    private fun filesContent(p: GlassPanel) {
        p.addRow("▸ التنزيلات").setOnClickListener {
            try { act.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (_: Exception) {}
        }
        p.addRow("▸ تصفح الملفات").setOnClickListener {
            try { act.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")) } catch (_: Exception) {}
        }
    }

    private fun browserContent(p: GlassPanel) {
        val url = EditText(act).apply {
            hint = "ابحث أو اكتب رابطاً"; setTextColor(-1); setHintTextColor(0xFF668899.toInt()); textSize = 13f
            setBackgroundColor(0x22FFFFFF); setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_GO
        }
        val wv = WebView(act).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
        }
        url.setOnEditorActionListener { v, _, _ ->
            val t = v.text.toString().trim()
            val u = if (t.startsWith("http")) t else if (t.contains(".") && !t.contains(" ")) "https://$t"
                    else "https://www.google.com/search?q=" + Uri.encode(t)
            wv.loadUrl(u); true
        }
        p.addView(url)
        p.addView(wv, LinearLayout.LayoutParams(-1, dp(260)))
        wv.loadUrl("https://www.google.com")
    }

    private companion object {
        const val REACT_PROMPT = "هذه لقطة من الكاميرا أمام المستخدم. انظر ماذا يفعل. إذا كان يمد صندوقاً أو علبة نحو الكاميرا فقل بالضبط: «لماذا تعطيني بوكس؟». إذا كان يرقص فقل: «أوه، تعرف كيف ترقص!». إذا كان يؤدي حركات رياضية أو قتالية فقل: «نينجا بالفطرة!». إذا كان يلعب بكرة القدم فقل: «أفضل من نيمار!». غير ذلك اجعل say نصاً فارغاً تماماً وactions فارغة."
    }
}
