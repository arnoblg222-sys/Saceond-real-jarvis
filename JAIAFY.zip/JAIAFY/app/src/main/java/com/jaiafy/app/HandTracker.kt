package com.jaiafy.app
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.File
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executor
import kotlin.math.hypot

/** يد واحدة: نقطة القرص (بين الإبهام والسبابة) بإحداثيات من 0 إلى 1 (معكوسة كالمرآة)، وهل هي مقروصة. */
data class Hand(val x: Float, val y: Float, val pinch: Boolean)

/** تتبع اليدين بـ MediaPipe. التتبع مخفي تماماً: لا يُرسم أي هيكل، تُسلَّم النقاط فقط. */
class HandTracker(
    private val ctx: Context,
    private val onHands: (List<Hand>) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object {
        private const val MODEL_URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }
    private var landmarker: HandLandmarker? = null
    @Volatile private var closed = false
    private var lastTs = 0L
    var onFrame: ((Bitmap) -> Unit)? = null
    val analysis: ImageAnalysis = ImageAnalysis.Builder()
        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()

    fun start(executor: Executor) {
        Thread { prepare() }.start()
        analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
    }

    private fun prepare() {
        try {
            val f = File(ctx.filesDir, "hand_landmarker.task")
            if (!f.exists() || f.length() < 1000000) {
                onStatus("تحميل نموذج تتبع اليد...")
                val tmp = File(ctx.filesDir, "hand.tmp")
                URL(MODEL_URL).openStream().use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                tmp.renameTo(f)
            }
            val bytes = f.readBytes()
            val bb = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            bb.put(bytes); bb.rewind()
            val opts = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(bb).build())
                .setNumHands(2)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setResultListener { res, _ -> handle(res) }
                .setErrorListener { _ -> }
                .build()
            if (closed) return
            landmarker = HandLandmarker.createFromOptions(ctx, opts)
            onStatus("")
        } catch (e: Exception) { onStatus("تعذر تشغيل تتبع اليد: " + (e.message ?: "").take(60)) }
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val raw = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = if (rot != 0) Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(rot.toFloat()) }, true) else raw
            onFrame?.invoke(bmp)
            val lm = landmarker
            if (lm != null && !closed) {
                val ts = System.currentTimeMillis().coerceAtLeast(lastTs + 1)
                lastTs = ts
                lm.detectAsync(BitmapImageBuilder(bmp).build(), ts)
            }
        } catch (_: Exception) {
        } finally { proxy.close() }
    }

    private fun handle(res: HandLandmarkerResult) {
        val out = ArrayList<Hand>()
        for (lm in res.landmarks()) {
            if (lm.size < 21) continue
            val thumb = lm[4]; val idx = lm[8]; val wrist = lm[0]; val mid = lm[9]
            val size = hypot(wrist.x() - mid.x(), wrist.y() - mid.y()).coerceAtLeast(0.01f)
            val gap = hypot(thumb.x() - idx.x(), thumb.y() - idx.y())
            val px = (thumb.x() + idx.x()) / 2f
            val py = (thumb.y() + idx.y()) / 2f
            out.add(Hand(1f - px, py, gap / size < 0.3f))
        }
        onHands(out)
    }

    fun close() {
        closed = true
        try { analysis.clearAnalyzer() } catch (_: Exception) {}
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
    }
}
