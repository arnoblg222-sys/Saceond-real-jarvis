package com.jaiafy.app
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** كل الإعدادات: المفاتيح، الشخصية، الأجهزة، الشبكة، التنبيهات. الحقول الفارغة لا تمسح القيم المحفوظة. */
class SettingsActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val cy = 0xFF5FE3FF.toInt()
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24)) }
        fun head(t: String) = form.addView(TextView(this).apply {
            text = t; setTextColor(cy); textSize = 16f; setPadding(0, dp(18), 0, dp(6)) })
        fun field(h: String, pass: Boolean = false, lines: Int = 1) = EditText(this).apply {
            hint = h; setTextColor(-1); setHintTextColor(0xFF668899.toInt()); textSize = 14f
            setBackgroundColor(0x22FFFFFF)
            inputType = if (pass) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        else if (lines > 1) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                        else InputType.TYPE_CLASS_TEXT
            if (lines > 1) minLines = lines
            form.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        fun btn(t: String, f: () -> Unit) {
            form.addView(Button(this).apply {
                text = t; isAllCaps = false; setTextColor(cy); textSize = 14f
                background = GradientDrawable().apply { cornerRadius = 10 * d; setColor(0x33104060); setStroke(dp(1), cy) }
                setOnClickListener { f() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        fun sw(label: String, key: String, invert: Boolean = false) {
            form.addView(Switch(this).apply {
                text = label; setTextColor(-1); textSize = 14f
                val v = Brain.get(this@SettingsActivity, key) == "1"
                isChecked = if (invert) !v else v
                setOnCheckedChangeListener { _, on -> Brain.put(this@SettingsActivity, key, if (on != invert) "1" else "0") }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        val saved = ArrayList<Pair<String, EditText>>()
        fun f(key: String, h: String, pass: Boolean = false, lines: Int = 1) { saved.add(key to field(h, pass, lines)) }

        form.addView(TextView(this).apply { text = "إعدادات جايفاي"; setTextColor(cy); textSize = 20f })

        head("العقل والصوت")
        val fKey = field("مفتاح OpenRouter (sk-or-...)", true)
        val fModel = field("النموذج (اتركه فارغاً للافتراضي)")
        f("fish_key", "مفتاح Fish Audio (اختياري)", true)
        f("fish_voice", "معرّف صوت Fish (اختياري)")

        head("الشخصية وطريقة الكلام")
        f("title", "بماذا ينادونك (مثل: سيدي، يا بطل)")
        f("persona", "الشخصية (مثل: مساعد وقور ساخر قليلاً)", false, 2)
        f("style", "طريقة الكلام (مثل: مختصر وحاسم، أو ودود ومرح)", false, 2)
        f("idle_min", "دقائق الصمت قبل أن يسأل أين أنت (الافتراضي 30، 0 للإيقاف)")

        head("الأجهزة")
        f("cam_url", "رابط كاميرا المراقبة rtsp://...")
        f("ha_url", "رابط Home Assistant http://192.168.x.x:8123")
        f("ha_token", "توكن Home Assistant", true)
        f("ha_entity", "كيان النور مثل light.salon")

        head("التحكم بجوالات أخرى عليها جايفاي (نفس الشبكة)")
        sw("تفعيل استقبال الأوامر من أجهزة جايفاي الأخرى", "remote_on")
        f("remote_token", "رمز سري مشترك (نفسه على كل الأجهزة)", true)
        f("remote_devices", "الأجهزة، سطر لكل جهاز بصيغة: اسم=عنوان IP", false, 3)

        head("التنبيهات")
        sw("وضع الحراسة: تنبيه عند سماع صوت مرتفع", "guard_on")
        f("tg_token", "توكن بوت Telegram (اختياري)", true)
        f("tg_chat", "معرّف محادثة Telegram")
        sw("تعليقات الكاميرا الذكية في Holo Desk", "react_off", invert = true)

        btn("حفظ") {
            if (fKey.text.isNotBlank()) Brain.saveKey(this, fKey.text.toString())
            if (fModel.text.isNotBlank()) Brain.saveModel(this, fModel.text.toString())
            for ((k, e) in saved) if (e.text.isNotBlank()) Brain.put(this, k, e.text.toString())
            Toast.makeText(this, "تم الحفظ، أعد تشغيل التطبيق لتفعيل الشبكة", Toast.LENGTH_SHORT).show()
        }

        head("الأذونات")
        btn("تفعيل التحكم بالشاشة") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }

        head("الذاكرة")
        btn("مسح ذاكرة جايفاي (الحقائق والمهارات)") {
            Memory(this).clear()
            Toast.makeText(this, "تم المسح", Toast.LENGTH_SHORT).show()
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF02070D.toInt()); addView(form) })
    }
}
