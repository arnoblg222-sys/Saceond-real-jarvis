package com.jaiafy.app
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.sin

/** بطل مدرّع صغير (أحمر وذهبي) يتمشى على الشاشة. رسم أصلي بالكود، يمكن استبداله بصورتك. */
class HeroView(c: Context) : View(c) {
    var facing = 1
    var walking = true
    @Volatile var tapUntil = 0L
    private val t0 = System.nanoTime()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun limb(cv: Canvas, px: Float, py: Float, ang: Float, w: Float, len: Float, color: Int, endColor: Int) {
        cv.save(); cv.translate(px, py); cv.rotate(ang)
        p.color = color; cv.drawRoundRect(RectF(-w / 2, 0f, w / 2, len), 3f, 3f, p)
        p.color = endColor; cv.drawCircle(0f, len, w * 0.6f, p)
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val s = height / 110f
        val tapping = System.currentTimeMillis() < tapUntil
        val swing = if (walking && !tapping) sin(t * 9f) * 22f else 0f
        val red = if (Mode.serious) 0xFF7A0F0F.toInt() else 0xFFC62828.toInt()
        val gold = 0xFFFFC107.toInt()
        val glow = if (Mode.serious) 0xFFFF5252.toInt() else 0xFF7FEFFF.toInt()
        cv.save()
        if (facing < 0) cv.scale(-1f, 1f, width / 2f, height / 2f)
        cv.translate(width / 2f - 30f * s, 0f); cv.scale(s, s)
        limb(cv, 24f, 62f, swing, 11f, 32f, red, gold)
        limb(cv, 36f, 62f, -swing, 11f, 32f, red, gold)
        p.color = red; cv.drawRoundRect(RectF(14f, 30f, 46f, 64f), 6f, 6f, p)
        p.color = gold; cv.drawRect(14f, 58f, 46f, 62f, p)
        p.color = glow; cv.drawCircle(30f, 44f, 6f + sin(t * 4f), p)
        limb(cv, 12f, 34f, -swing, 8f, 24f, red, gold)
        limb(cv, 48f, 34f, if (tapping) -75f else swing, 8f, 24f, red, gold)
        p.color = red; cv.drawCircle(30f, 20f, 12f, p)
        p.color = gold; cv.drawRoundRect(RectF(22f, 13f, 38f, 29f), 4f, 4f, p)
        p.color = glow; cv.drawRect(24f, 18f, 29f, 21f, p); cv.drawRect(31f, 18f, 36f, 21f, p)
        if (tapping) {
            val k = (tapUntil - System.currentTimeMillis()) / 700f
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = glow
            cv.drawCircle(70f, 12f, 4f + (1f - k) * 14f, p)
            p.style = Paint.Style.FILL
        }
        cv.restore()
        postInvalidateOnAnimation()
    }
}
