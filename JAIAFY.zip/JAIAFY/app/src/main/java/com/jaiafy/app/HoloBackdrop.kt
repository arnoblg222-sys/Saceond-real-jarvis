package com.jaiafy.app
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** خلفية هولوغرافية متحركة: أرضية شبكية بمنظور، جزيئات صاعدة، حلقة ماسحة، وأقواس زوايا. */
class HoloBackdrop(c: Context) : View(c) {
    private val t0 = System.nanoTime()
    private val ln = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private fun col(a: Int, rgb: Int) = (a shl 24) or (rgb and 0xFFFFFF)

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val rgb = if (Mode.serious) 0xFF4D4D else 0x5FE3FF
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val hz = h * 0.62f
        ln.color = col(0x44, rgb)
        for (i in -10..10) cv.drawLine(cx + i * w * 0.10f, h, cx + i * w * 0.012f, hz, ln)
        val n = 8
        for (k in 0 until n) {
            val f = (k + (t * 0.4f) % 1f) / n
            val y = hz + (h - hz) * f * f
            cv.drawLine(0f, y, w, y, ln)
        }
        for (i in 0 until 36) {
            val x = ((i * 97) % 100) / 100f * w
            val speed = 20f + (i % 7) * 6f
            val y = (((((i * 53) % 100) / 100f * h) - t * speed) % h + h) % h
            dot.color = col(0x88, rgb)
            cv.drawCircle(x, y, 1.5f + (i % 3), dot)
        }
        val r = minOf(w, h) * 0.34f
        ln.color = col(0x55, rgb); ln.strokeWidth = 2f
        cv.drawArc(cx - r, h * 0.4f - r, cx + r, h * 0.4f + r, t * 30f, 70f, false, ln)
        cv.drawArc(cx - r, h * 0.4f - r, cx + r, h * 0.4f + r, t * 30f + 180f, 70f, false, ln)
        ln.strokeWidth = 3f; ln.color = col(0xAA, rgb)
        val L = 32f * resources.displayMetrics.density; val m = 10f
        cv.drawLine(m, m, m + L, m, ln); cv.drawLine(m, m, m, m + L, ln)
        cv.drawLine(w - m, m, w - m - L, m, ln); cv.drawLine(w - m, m, w - m, m + L, ln)
        cv.drawLine(m, h - m, m + L, h - m, ln); cv.drawLine(m, h - m, m, h - m - L, ln)
        cv.drawLine(w - m, h - m, w - m - L, h - m, ln); cv.drawLine(w - m, h - m, w - m, h - m - L, ln)
        ln.strokeWidth = 1.5f
        postInvalidateOnAnimation()
    }
}
