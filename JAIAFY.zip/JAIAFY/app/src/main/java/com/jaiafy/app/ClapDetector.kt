package com.jaiafy.app
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.abs

/** يكتشف تصفيقتين متتاليتين، ويمرّر الصوت للتسجيل، ويبلّغ عن الأصوات المرتفعة المستمرة. */
class ClapDetector(
    private val onDoubleClap: () -> Unit,
    private val onLoud: ((Int) -> Unit)? = null
) {
    @Volatile private var running = false
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        thread = Thread {
            val rate = 16000
            val buf = ShortArray(AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT))
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf.size * 2)
            rec.startRecording()
            var last = 0L; var lastClap = 0L; var loudCount = 0
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                var peak = 0
                var sum = 0.0
                for (i in 0 until n) { peak = maxOf(peak, abs(buf[i].toInt())); sum += buf[i].toDouble() * buf[i] }
                val rms = Math.sqrt(sum / n).toInt()
                if (rms > 2500) { loudCount++; if (loudCount >= 8) { loudCount = 0; onLoud?.invoke(rms) } } else loudCount = 0
                val now = System.currentTimeMillis()
                if (peak > 20000 && now - last > 120) {          // حدة الصوت (عدّلها للحساسية)
                    if (now - lastClap in 150..700) { running = false; onDoubleClap() }
                    lastClap = now; last = now
                }
            }
            rec.stop(); rec.release()
        }.also { it.start() }
    }
    fun stop() { running = false; thread?.join(500) }
}
