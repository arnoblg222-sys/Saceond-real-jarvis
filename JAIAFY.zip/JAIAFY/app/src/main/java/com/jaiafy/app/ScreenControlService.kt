package com.jaiafy.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** التحكم بالشاشة: ضغط، كتابة، تمرير، رجوع... داخل أي تطبيق. */
class ScreenControlService : AccessibilityService() {
    companion object { var inst: ScreenControlService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }

    fun clickText(t: String): Boolean {
        val n = rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull() ?: return false
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return (x ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }
    fun typeText(t: String) {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
            Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
    }
    fun swipe(up: Boolean) {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
        val p = Path().apply { if (up) { moveTo(x, a); lineTo(x, b) } else { moveTo(x, b); lineTo(x, a) } }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "لا يوجد محتوى ظاهر"
        val out = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.length > 3000) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) out.append(t.take(120)).append(if (n.isClickable) " [زر]" else "").append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out.toString().ifBlank { "الشاشة بلا نصوص ظاهرة" }
    }
    fun tap(fx: Float, fy: Float) {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(fx * m.widthPixels, fy * m.heightPixels); lineTo(fx * m.widthPixels, fy * m.heightPixels) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun swipeDir(dir: String) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
        val p = Path().apply {
            when (dir) {
                "up" -> { moveTo(w / 2, h * 0.7f); lineTo(w / 2, h * 0.3f) }
                "down" -> { moveTo(w / 2, h * 0.3f); lineTo(w / 2, h * 0.7f) }
                "left" -> { moveTo(w * 0.8f, h / 2); lineTo(w * 0.2f, h / 2) }
                else -> { moveTo(w * 0.2f, h / 2); lineTo(w * 0.8f, h / 2) }
            }
        }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(), null, null)
    }
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
}
