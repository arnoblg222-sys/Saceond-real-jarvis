package com.jaiafy.app

/** قنوات مشتركة بين الواجهة والخدمة. */
object Bus {
    @Volatile var say: ((String) -> Unit)? = null
    @Volatile var faceSeenAt = 0L
    @Volatile var lastUserAt = System.currentTimeMillis()
    fun faceVisible() = System.currentTimeMillis() - faceSeenAt < 5000
}
