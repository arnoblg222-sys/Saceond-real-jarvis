package com.jaiafy.app
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** بطاقة المهمة: STANDBY عند الخمول، وعنوان المهمة وخطواتها أثناء التنفيذ، وملخص عند الانتهاء. */
class TaskCardView(c: Context) : View(c) {
    private val d = resources.displayMetrics.density
    private val box = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }

    override fun onDraw(cv: Canvas) {
        val main = if (Mode.serious) 0xFFFF4D4D.toInt() else 0xFF2EE6A8.toInt()
        val w = width.toFloat(); val h = height.toFloat()
        box.style = Paint.Style.FILL; box.color = 0xCC03121A.toInt()
        cv.drawRoundRect(RectF(0f, 0f, w, h), 8 * d, 8 * d, box)
        box.style = Paint.Style.STROKE; box.strokeWidth = 1.5f * d; box.color = main
        cv.drawRoundRect(RectF(1f, 1f, w - 1f, h - 1f), 8 * d, 8 * d, box)

        val tag: String; val line1: String; val line2: String
        when {
            TaskLog.running -> {
                tag = "TASK"; line1 = TaskLog.title.take(26)
                line2 = "STEP " + TaskLog.steps + "  " + (TaskLog.log.lastOrNull() ?: "").take(20)
            }
            TaskLog.endMs > 0L && System.currentTimeMillis() - TaskLog.endMs < 20000 -> {
                tag = "DONE"; line1 = TaskLog.seconds().toString() + " S  •  " + TaskLog.steps + " STEPS"
                line2 = TaskLog.summary.take(30)
            }
            else -> { tag = "STANDBY"; line1 = "LOCAL BRAIN"; line2 = "" }
        }
        tx.color = main; tx.textSize = 11 * d
        cv.drawText(tag, 12 * d, 20 * d, tx)
        tx.color = 0xFFFFFFFF.toInt(); tx.textSize = 12 * d
        cv.drawText(line1, 12 * d, 40 * d, tx)
        tx.color = 0xFF8FA6B8.toInt(); tx.textSize = 10 * d
        cv.drawText(line2, 12 * d, 58 * d, tx)
        postInvalidateDelayed(300)
    }
}
